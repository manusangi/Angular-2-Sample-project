﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;

namespace EmployeeAPIService.Controllers
{
    public class EmployeeController : ApiController
    {
        public IEnumerable<tbl_Employee> Get()
        {
            using (Access_TestDBEntities entities = new Access_TestDBEntities())
            {
                return entities.tbl_Employee.ToList();
            }
        }
        public tbl_Employee Get(string code)
        {
            using (Access_TestDBEntities entities = new Access_TestDBEntities())
            {
                return entities.tbl_Employee.FirstOrDefault(e => e.code == code);
            }
        }
    }
}
