import java.io.BufferedOutputStream;
import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class GetEmpDetail
 */
public class GetEmpDetail extends HttpServlet {
	private static final long serialVersionUID = 1L;
    
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		//Data will be fetch from db source
		System.out.println("Here");
		PrintWriter out = response.getWriter();
		String jsonObj = "{empId :'101',empName :'Tom',dept :'GE'}";
		out.write(jsonObj);
	}
}