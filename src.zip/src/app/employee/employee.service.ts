﻿import { Injectable } from '@angular/core';
import { IEmployee } from './employee';
import { Http,Response } from '@angular/http';
import { Observable } from "rxjs/Observable";
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/catch';
import 'rxjs/add/operator/throw';


@Injectable()
export class EmployeeService
{
   
    constructor(private _http: Http)
    {

    }
    getEmployees(): Observable<IEmployee[]> {
        return this._http.get("http://localhost:58124/api/employee")
            .map((response: Response) => <IEmployee[]>response.json())
            .catch(this.handleError);
        //return [
        //    { code: 'emp101', name: 'Tom', gender: 'Male', annualSalary: 5500, dateOfBirth: '6/6/1988' },
        //    { code: 'emp102', name: 'Alex', gender: 'Male', annualSalary: 6000.25, dateOfBirth: '9/7/1982' },
        //    { code: 'emp103', name: 'Mike', gender: 'Male', annualSalary: 6500.43, dateOfBirth: '12/8/1978' },
        //    { code: 'emp104', name: 'Nancy', gender: 'FeMale', annualSalary: 6300.43, dateOfBirth: '12/9/1979' },
        //    { code: 'emp105', name: 'Mary', gender: 'FeMale', annualSalary: 6200.43, dateOfBirth: '12/9/1989' }
        //];        
    }
    getEmployeeByCode(empcode: string): Observable<IEmployee[]> {
        return this._http.get("http://localhost:58124/api/employee/" + empcode)
            .map((response: Response) => <IEmployee[]>response.json())
            .catch(this.handleError);
               
    }
    handleError(error: Response)
    {
        console.error(error);
        return Observable.throw(error);
    }
}