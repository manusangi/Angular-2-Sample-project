﻿import { Component, OnInit } from '@angular/core';
import { IEmployee } from './employee';
import {EmployeeService} from './employee.service';
@Component({
    selector: 'list-employee',
    templateUrl: 'app/employee/EmployeeList.component.html',
    styleUrls: ['app/employee/EmployeeList.component.css'] 
})
export class EmployeeListComponent implements OnInit
{
    employees: IEmployee[];
    selectEmployeeCountRadioButton: string = 'All';
    statusMessage: string='Loading Data.Please wait...' ;
    constructor(private _employeeService: EmployeeService)
    {
       
    }
    ngOnInit()
    {
        this._employeeService.getEmployees().subscribe(employeeData => this.employees = employeeData, (error) => {
            this.statusMessage = 'Problem with service.Please try again after some time.';
            
        });
    }
    //getEmployees(): void {
    //    this.employees = [
    //        { code: 'emp101', name: 'Tom', gender: 'Male', annualSalary: '5500', dateOfBirth: '6/6/1988' },
    //        { code: 'emp102', name: 'Alex', gender: 'Male', annualSalary: '6000.25', dateOfBirth: '9/7/1982' },
    //        { code: 'emp103', name: 'Mike', gender: 'Male', annualSalary: '6500.43', dateOfBirth: '12/8/1978' },
    //        { code: 'emp104', name: 'Mike', gender: 'FeMale', annualSalary: '6300.43', dateOfBirth: '12/9/1979' }
    //        { code: 'emp105', name: 'Mary', gender: 'FeMale', annualSalary: '6600.78', dateOfBirth: '10/12/2001' }
    //    ];
    //}
    trackByEmpCode(index: number, employee: any):string
    {
        return employee.code;
    }
    onEmployeeCountradioButtonChange(selectedRadioButtonvalue: string): void {
        this.selectEmployeeCountRadioButton = selectedRadioButtonvalue;
    }
    getEmployeesCount(): number {
        return this.employees.length;
    }
    getMaleEmployeesCount(): number {
        return this.employees.filter(e => e.gender == 'Male').length;
    }
    getFeMaleEmployeesCount(): number {
        return this.employees.filter(e => e.gender == 'FeMale').length;
    }
    
}