﻿import { Component ,OnInit} from '@angular/core';
import { IEmployee } from './employee';
import { ActivatedRoute } from '@angular/router';
import { EmployeeService } from './employee.service';


@Component({
    selector: 'my-employee',
    templateUrl: 'app/employee/employee.component.html',
    styleUrls: ['app/employee/employee.component.css']
    //styles: ['table {color: #369;font-family: Arial, Helvetica, sans-serif; font-size: large; border-collapse:collapse;}', 'td {border:1px solid black}']
})
export class EmployeeComponent implements OnInit {
    //firstName: string = 'Tom';
    //lastName: string = 'Hopkins';
    //gender: string = 'Male';
    //age: number = 20;
    showDetails: boolean = false;
    toggleDetails(): void {
        this.showDetails = !this.showDetails;
    }
    employee: IEmployee[];
    statusMessage: string;
    constructor(private _employeeService : EmployeeService, private _activatedRoute : ActivatedRoute)
    {

    }
    ngOnInit() {
        let empcode: string = this._activatedRoute.snapshot.params['code'];
        this._employeeService.getEmployeeByCode(empcode).subscribe(employeeData => this.employee = employeeData, (error) => {
            this.statusMessage = 'Problem with service.Please try again after some time.';

        });
    }
}