﻿import { Component,Input,Output,EventEmitter } from '@angular/core'
@Component({
    selector: 'employee-count',
    templateUrl: 'app/employee/employeeCount.component.html',
    styleUrls:['app/employee/employeeCount.component.css']
})
export class EmployeeCountComponent 
{
    selectedRadioButtonvalue: string = 'All';

    @Output()
    countReadioButtonSelectionChanged: EventEmitter<string>=new EventEmitter<string>();

    @Input()
    all: number;
    @Input()
    male: number;
    @Input()
    female: number;

    onRadioButtonSelectionChange()
    {
        this.countReadioButtonSelectionChanged.emit(this.selectedRadioButtonvalue);
        console.log(this.selectedRadioButtonvalue);
    }
}