"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
var core_1 = require("@angular/core");
var AppComponent = (function () {
    function AppComponent() {
        this.pageHeader = 'Employee Details';
        this.Imagepath = 'http://www.pragimtech.com/Images/Logo.JPG';
        this.firstName = 'Tom';
        this.lastName = 'Hopkins';
        this.isDisabled = false;
        this.columSpan = 2;
        this.classesToapply = 'italicClass boldClass';
        this.addBoldClass = true;
        this.fontSize = 30;
        this.isBold = true;
        this.isItalic = true;
        this.name = 'Tom';
    }
    AppComponent.prototype.getFullName = function () {
        return this.firstName + " " + this.lastName;
    };
    AppComponent.prototype.onClick = function () {
        console.log("button Clicked");
    };
    AppComponent.prototype.addClasses = function () {
        var classes = {
            boldClass: this.addBoldClass
        };
        return classes;
    };
    AppComponent.prototype.addStyles = function () {
        var styles = {
            'font-size.px': this.fontSize,
            'font-weight': this.isBold ? 'bold' : 'normal',
            'font-style': this.isItalic ? 'italic' : 'normal'
        };
        return styles;
    };
    return AppComponent;
}());
AppComponent = __decorate([
    core_1.Component({
        selector: 'my-app',
        template: "\n            <div>\n<h1>{{getFullName()}}</h1>\n<img [src]=\"Imagepath\">\n<my-employee></my-employee>\n<span [class.boldClass]='addBoldClass'>Event Binding</span><br/>\n<button [disabled]='isDisabled'(click)='onClick()' class='colorClass' [class]='classesToapply'>Click me</button><br/><span [class.boldClass]='addBoldClass'>Class Binding</span><br/>\n<button class='colorClass italicClass boldClass' [class.boldClass]='addBoldClass'>Click me</button><br/>\n<button class='colorClass' [ngClass]='addClasses()'>Click me</button><br/>\n<span [class.boldClass]='addBoldClass'>Style Binding</span><br/>\n<button style='color:red' [style.fontWeight]=\"isBold ? 'bold': 'normal'\">Click me</button><br/>\n<button style='color:red' [style.font-size.px]=\"fontSize\">Click me</button><br/>\n<button style='color:red' [ngStyle]='addStyles()'>Click me</button><br/>\n\n<span bind-innerHTML='pageHeader'></span><br/>\n<span [class.boldClass]='addBoldClass'>Two way data Binding</span><br/>\nName<div><input [value]='name' (input)='name=$event.target.value' /> your entered {{name}}<br/>\nName<div><input [(ngModel)]='name' /> your entered {{name}}<br/>\n<list-employee></list-employee>\n<span [class.boldClass]='addBoldClass'>Routing in Anugular 2</span><br/>\n<div style=\"padding:5px;\">\n<ul class=\"nav nav-tabs\">\n<li><a routerLinkActive=\"Active\" routerLink=\"home\">Home</a></li>\n<li><a  routerLinkActive=\"Active\" routerLink=\"employees\">Employees</a></li>\n</ul>\n<router-outlet></router-outlet>\n</div>\n\n\n\n</div>\n",
    })
], AppComponent);
exports.AppComponent = AppComponent;
//# sourceMappingURL=app.component.js.map