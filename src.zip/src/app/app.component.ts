import { Component } from '@angular/core';

@Component({
  selector: 'my-app',
  template: `
            <div>
<h1>{{getFullName()}}</h1>
<img [src]="Imagepath">
<my-employee></my-employee>
<span [class.boldClass]='addBoldClass'>Event Binding</span><br/>
<button [disabled]='isDisabled'(click)='onClick()' class='colorClass' [class]='classesToapply'>Click me</button><br/><span [class.boldClass]='addBoldClass'>Class Binding</span><br/>
<button class='colorClass italicClass boldClass' [class.boldClass]='addBoldClass'>Click me</button><br/>
<button class='colorClass' [ngClass]='addClasses()'>Click me</button><br/>
<span [class.boldClass]='addBoldClass'>Style Binding</span><br/>
<button style='color:red' [style.fontWeight]="isBold ? 'bold': 'normal'">Click me</button><br/>
<button style='color:red' [style.font-size.px]="fontSize">Click me</button><br/>
<button style='color:red' [ngStyle]='addStyles()'>Click me</button><br/>

<span bind-innerHTML='pageHeader'></span><br/>
<span [class.boldClass]='addBoldClass'>Two way data Binding</span><br/>
Name<div><input [value]='name' (input)='name=$event.target.value' /> your entered {{name}}<br/>
Name<div><input [(ngModel)]='name' /> your entered {{name}}<br/>
<list-employee></list-employee>
<span [class.boldClass]='addBoldClass'>Routing in Anugular 2</span><br/>
<div style="padding:5px;">
<ul class="nav nav-tabs">
<li><a routerLinkActive="Active" routerLink="home">Home</a></li>
<li><a  routerLinkActive="Active" routerLink="employees">Employees</a></li>
</ul>
<router-outlet></router-outlet>
</div>



</div>
`,
  
})
export class AppComponent  { 
    pageHeader = 'Employee Details'; 
    Imagepath = 'http://www.pragimtech.com/Images/Logo.JPG';
    firstName: string = 'Tom';
    lastName: string = 'Hopkins'
    isDisabled: boolean = false;
    columSpan: number = 2;
    getFullName(): string {
        return this.firstName + " " + this.lastName;

    }
    onClick(): void{
        console.log("button Clicked");
    }
    classesToapply: string = 'italicClass boldClass'
    addBoldClass: boolean = true;
    addClasses() {
        let classes = {
            boldClass: this.addBoldClass
        };
        return classes;

    }
    fontSize: number = 30;
    isBold: boolean = true;
    isItalic: boolean = true;
    addStyles()
    {
        let styles = {
            'font-size.px': this.fontSize,
            'font-weight': this.isBold ? 'bold' : 'normal',
            'font-style': this.isItalic ? 'italic' : 'normal'
        };
        return styles;
    }
    name: string='Tom'
  

}
